﻿using UsandoBanco;
using UsandoBanco.BancoDados;

//DBInfo.TestDBConnection();

var menu = new Menu();
menu.ChamarMenu();

//var nome1 = "Marco";
//var nome2 = nome1;

//var produto1 = new Produto()
//{
//    Nome = "Pneu",
//    Descricao = "De borracha",
//};

//var produto2 = produto1;

//Console.WriteLine(nome1);
//Console.WriteLine(nome2);
//Console.WriteLine(produto1.Nome);
//Console.WriteLine(produto2.Nome);

//Console.WriteLine("=-=-=-=-=-=-=");
//nome1 = "Marco Antonio Angelo";
//produto1.Nome = "Pneu de corrida";

//Console.WriteLine(nome1);
//Console.WriteLine(nome2);
//Console.WriteLine(produto1.Nome);
//Console.WriteLine(produto2.Nome);